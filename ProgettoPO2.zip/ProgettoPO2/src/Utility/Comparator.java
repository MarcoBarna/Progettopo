package Utility;

public class Comparator<D> {
    public boolean lessThan (Comparable<D> a, Comparable<D> b ){
        return false;
    }
    public boolean MoreThan (Comparable<D> a, Comparable<D> b ){
        return false;
    }
    public boolean equal (Comparable<D> a, Comparable<D> b ){
        return false;
    }
}
