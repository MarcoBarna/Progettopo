package Utility;

public interface Comparable<D> {
    public Integer value();
}
