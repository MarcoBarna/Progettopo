package SortingAlgorithms;

public class QuickSort {
}
