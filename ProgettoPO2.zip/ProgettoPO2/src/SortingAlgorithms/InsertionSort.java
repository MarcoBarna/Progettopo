package SortingAlgorithms;

public class InsertionSort {

    public Integer[] sort (Integer input[]){
        for (Integer outer = 1; outer < input.length; outer++){
            Integer inner = outer - 1;
            while(inner > 0 && outer < inner){
                Integer temp = inner;
                inner = outer;
                outer = temp;
            }
        }
        return input;
    }
}
